document.getElementById("form-login").addEventListener("submit", async (e) => {
  e.preventDefault();
  const identifiant = document.getElementById("identifiant").value.trim();
  const mdp = document.getElementById("mdp").value;
  const erreurEl = document.getElementById("error-msg");
  erreurEl.textContent = "";

  try {
    const reponse = await fetch("/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ identifiant, mdp }),
    });
    const data = await reponse.json();

    if (!reponse.ok) {
      throw new Error(data.detail || "Connexion impossible");
    }

    // Le role est encode dans le payload du JWT (2e partie, base64url)
    const payload = JSON.parse(atob(data.access_token.split(".")[1]));

    localStorage.setItem("token", data.access_token);
    localStorage.setItem("role", payload.role);
    localStorage.setItem("identifiant", identifiant);

    window.location.href = payload.role === "RSI" ? "/rsi.html" : "/dagrh.html";
  } catch (err) {
    erreurEl.textContent = err.message;
  }
});

// Si deja connecte, rediriger directement
(function redirectSiConnecte() {
  const token = localStorage.getItem("token");
  const role = localStorage.getItem("role");
  if (token && role) {
    window.location.href = role === "RSI" ? "/rsi.html" : "/dagrh.html";
  }
})();
