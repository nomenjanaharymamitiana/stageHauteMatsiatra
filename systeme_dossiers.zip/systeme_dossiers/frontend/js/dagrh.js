exigerConnexion("DAG_RH");
document.getElementById("user-label").textContent = getIdentifiant();

const BADGE_CLASSES = {
  NOMINATION: "badge-nomination",
  FINANCE: "badge-finance",
  DEVELOPPEMENT: "badge-developpement",
};

const LABELS_CAT = {
  NOMINATION: "Nomination",
  FINANCE: "Finance",
  DEVELOPPEMENT: "Développement",
};

async function chargerDocuments() {
  const q = document.getElementById("q").value.trim();
  const cat = document.getElementById("filtre-cat").value;
  const annee = document.getElementById("filtre-annee").value;

  const params = new URLSearchParams();
  if (q) params.set("q", q);
  if (cat) params.set("cat", cat);
  if (annee) params.set("annee", annee);

  try {
    const documents = await apiJson("/documents/?" + params.toString());
    const corps = document.getElementById("tbody-documents");
    const videEl = document.getElementById("documents-vide");
    corps.innerHTML = "";

    if (documents.length === 0) {
      videEl.classList.remove("hidden");
      return;
    }
    videEl.classList.add("hidden");

    for (const doc of documents) {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${doc.num_ref}</td>
        <td><span class="badge ${BADGE_CLASSES[doc.cat]}">${LABELS_CAT[doc.cat]}</span></td>
        <td>${doc.format}</td>
        <td>${formatDate(doc.date_num)}</td>
        <td>
          <button class="btn btn-outline btn-sm" onclick="telecharger(${doc.id}, '${doc.num_ref}', '${doc.format}')">Télécharger</button>
          <button class="btn btn-outline btn-sm" onclick="imprimer(${doc.id})">Imprimer</button>
          <button class="btn btn-danger btn-sm" onclick="supprimer(${doc.id})">Supprimer</button>
        </td>`;
      corps.appendChild(tr);
    }
  } catch (err) {
    alert("Erreur lors du chargement des documents : " + err.message);
  }
}

async function telecharger(id, numRef, format) {
  try {
    await apiTelecharger(`/documents/${id}/telecharger`, `${numRef}.${format}`, "download");
  } catch (err) {
    alert(err.message);
  }
}

async function imprimer(id) {
  try {
    await apiTelecharger(`/documents/${id}/telecharger`, null, "print");
  } catch (err) {
    alert(err.message);
  }
}

async function supprimer(id) {
  if (!confirm("Supprimer ce document ? Il pourra être restauré par le RSI.")) return;
  try {
    await apiJson(`/documents/${id}`, { method: "DELETE" });
    chargerDocuments();
  } catch (err) {
    alert("Erreur : " + err.message);
  }
}

document.getElementById("form-upload").addEventListener("submit", async (e) => {
  e.preventDefault();
  const msgEl = document.getElementById("upload-msg");
  msgEl.textContent = "";

  const formData = new FormData();
  formData.append("num_ref", document.getElementById("num_ref").value);
  formData.append("cat", document.getElementById("cat").value);
  formData.append("format", document.getElementById("format").value);
  formData.append("date_num", document.getElementById("date_num").value);
  formData.append("annee_redac", document.getElementById("annee_redac").value);
  formData.append("fichier", document.getElementById("fichier").files[0]);

  try {
    await apiJson("/documents/", { method: "POST", body: formData });
    document.getElementById("form-upload").reset();
    chargerDocuments();
  } catch (err) {
    msgEl.textContent = err.message;
  }
});

chargerDocuments();
