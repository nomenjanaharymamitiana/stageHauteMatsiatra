// api.js — helper commun pour tout le frontend

const API_BASE = ""; // meme origine que le frontend (servi par FastAPI)

function getToken() {
  return localStorage.getItem("token");
}

function getRole() {
  return localStorage.getItem("role");
}

function getIdentifiant() {
  return localStorage.getItem("identifiant");
}

function seDeconnecter() {
  localStorage.removeItem("token");
  localStorage.removeItem("role");
  localStorage.removeItem("identifiant");
  window.location.href = "/index.html";
}

function exigerConnexion(roleAttendu) {
  const token = getToken();
  const role = getRole();
  if (!token || (roleAttendu && role !== roleAttendu)) {
    window.location.href = "/index.html";
  }
}

/**
 * Appel API generique en JSON. Redirige vers le login si le token est invalide/expire.
 */
async function apiFetch(path, options = {}) {
  const headers = options.headers || {};
  const token = getToken();
  if (token) headers["Authorization"] = "Bearer " + token;
  if (options.body && !(options.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }

  const reponse = await fetch(API_BASE + path, { ...options, headers });

  if (reponse.status === 401) {
    seDeconnecter();
    throw new Error("Session expiree");
  }

  return reponse;
}

async function apiJson(path, options = {}) {
  const reponse = await apiFetch(path, options);
  const data = await reponse.json().catch(() => null);
  if (!reponse.ok) {
    const message = (data && data.detail) || `Erreur ${reponse.status}`;
    throw new Error(message);
  }
  return data;
}

/**
 * Telecharge un fichier protege (avec Authorization) et le sauvegarde
 * ou l'ouvre selon le mode choisi.
 */
async function apiTelecharger(path, nomFichier, mode = "download") {
  const reponse = await apiFetch(path);
  if (!reponse.ok) {
    const data = await reponse.json().catch(() => null);
    throw new Error((data && data.detail) || "Impossible de telecharger le fichier");
  }
  const blob = await reponse.blob();
  const url = window.URL.createObjectURL(blob);

  if (mode === "print") {
    const fenetre = window.open(url, "_blank");
    if (fenetre) {
      fenetre.onload = () => {
        try { fenetre.focus(); fenetre.print(); } catch (e) { /* navigateur restrictif */ }
      };
    }
  } else {
    const lien = document.createElement("a");
    lien.href = url;
    lien.download = nomFichier || "document";
    document.body.appendChild(lien);
    lien.click();
    lien.remove();
  }
  setTimeout(() => window.URL.revokeObjectURL(url), 30000);
}

function formatDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString("fr-FR");
}

function formatDateHeure(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString("fr-FR");
}
