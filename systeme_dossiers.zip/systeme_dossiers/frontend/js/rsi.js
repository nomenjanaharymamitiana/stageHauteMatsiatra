exigerConnexion("RSI");
document.getElementById("user-label").textContent = getIdentifiant();

// --- Navigation par onglets ---
document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach((s) => s.classList.add("hidden"));
    btn.classList.add("active");
    document.getElementById("tab-" + btn.dataset.tab).classList.remove("hidden");

    if (btn.dataset.tab === "dashboard") chargerStats();
    if (btn.dataset.tab === "utilisateurs") chargerUtilisateurs();
    if (btn.dataset.tab === "journal") chargerJournal();
    if (btn.dataset.tab === "corbeille") chargerCorbeille();
  });
});

// --- Tableau de bord ---
async function chargerStats() {
  try {
    const stats = await apiJson("/rsi/dashboard/stats");
    const grille = document.getElementById("stats-grid");
    grille.innerHTML = `
      <div class="stat-box"><div class="value">${stats.utilisateurs.total}</div><div class="label">Utilisateurs (total)</div></div>
      <div class="stat-box"><div class="value">${stats.utilisateurs.actifs}</div><div class="label">Comptes actifs</div></div>
      <div class="stat-box"><div class="value">${stats.utilisateurs.rsi}</div><div class="label">RSI</div></div>
      <div class="stat-box"><div class="value">${stats.utilisateurs.dag_rh}</div><div class="label">DAG/RH</div></div>
      <div class="stat-box"><div class="value">${stats.documents.total}</div><div class="label">Documents (total)</div></div>
      <div class="stat-box"><div class="value">${stats.documents.supprimes}</div><div class="label">En corbeille</div></div>
      <div class="stat-box"><div class="value">${stats.documents.par_categorie.NOMINATION}</div><div class="label">Nomination</div></div>
      <div class="stat-box"><div class="value">${stats.documents.par_categorie.FINANCE}</div><div class="label">Finance</div></div>
      <div class="stat-box"><div class="value">${stats.documents.par_categorie.DEVELOPPEMENT}</div><div class="label">Développement</div></div>
      <div class="stat-box"><div class="value">${stats.journal.total_actions}</div><div class="label">Actions journalisées</div></div>
    `;
  } catch (err) {
    alert("Erreur : " + err.message);
  }
}

// --- Utilisateurs ---
async function chargerUtilisateurs() {
  try {
    const utilisateurs = await apiJson("/rsi/utilisateurs/");
    const corps = document.getElementById("tbody-utilisateurs");
    corps.innerHTML = "";
    for (const u of utilisateurs) {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${u.identifiant}</td>
        <td>${u.prenom} ${u.nom}</td>
        <td>${u.role}</td>
        <td><span class="badge ${u.actif ? "badge-on" : "badge-off"}">${u.actif ? "Actif" : "Désactivé"}</span></td>
        <td>
          ${u.actif ? `<button class="btn btn-danger btn-sm" onclick="desactiverUtilisateur(${u.id})">Désactiver</button>` : ""}
        </td>`;
      corps.appendChild(tr);
    }
  } catch (err) {
    alert("Erreur : " + err.message);
  }
}

async function desactiverUtilisateur(id) {
  if (!confirm("Désactiver ce compte ?")) return;
  try {
    await apiJson(`/rsi/utilisateurs/${id}/desactiver`, { method: "PATCH" });
    chargerUtilisateurs();
  } catch (err) {
    alert("Erreur : " + err.message);
  }
}

document.getElementById("form-utilisateur").addEventListener("submit", async (e) => {
  e.preventDefault();
  const msgEl = document.getElementById("u-msg");
  msgEl.textContent = "";

  const payload = {
    identifiant: document.getElementById("u-identifiant").value,
    nom: document.getElementById("u-nom").value,
    prenom: document.getElementById("u-prenom").value,
    mdp: document.getElementById("u-mdp").value,
    role: document.getElementById("u-role").value,
  };

  try {
    await apiJson("/rsi/utilisateurs/", { method: "POST", body: JSON.stringify(payload) });
    document.getElementById("form-utilisateur").reset();
    chargerUtilisateurs();
  } catch (err) {
    msgEl.textContent = err.message;
  }
});

// --- Journal ---
async function chargerJournal() {
  const debut = document.getElementById("j-debut").value;
  const fin = document.getElementById("j-fin").value;
  const params = new URLSearchParams();
  if (debut) params.set("date_debut", debut + "T00:00:00");
  if (fin) params.set("date_fin", fin + "T23:59:59");

  try {
    const entrees = await apiJson("/rsi/journal/?" + params.toString());
    const corps = document.getElementById("tbody-journal");
    const videEl = document.getElementById("journal-vide");
    corps.innerHTML = "";

    if (entrees.length === 0) {
      videEl.classList.remove("hidden");
      return;
    }
    videEl.classList.add("hidden");

    for (const entree of entrees) {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${formatDateHeure(entree.date_action)}</td>
        <td>#${entree.utilisateur_id}</td>
        <td>${entree.desc}</td>
        <td>${entree.document_id ? "#" + entree.document_id : "—"}</td>`;
      corps.appendChild(tr);
    }
  } catch (err) {
    alert("Erreur : " + err.message);
  }
}

// --- Corbeille ---
const LABELS_CAT = { NOMINATION: "Nomination", FINANCE: "Finance", DEVELOPPEMENT: "Développement" };

async function chargerCorbeille() {
  try {
    const documents = await apiJson("/rsi/documents/supprimes");
    const corps = document.getElementById("tbody-corbeille");
    const videEl = document.getElementById("corbeille-vide");
    corps.innerHTML = "";

    if (documents.length === 0) {
      videEl.classList.remove("hidden");
      return;
    }
    videEl.classList.add("hidden");

    for (const doc of documents) {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${doc.num_ref}</td>
        <td>${LABELS_CAT[doc.cat]}</td>
        <td>${doc.format}</td>
        <td><button class="btn btn-primary btn-sm" onclick="restaurerDocument(${doc.id})">Restaurer</button></td>`;
      corps.appendChild(tr);
    }
  } catch (err) {
    alert("Erreur : " + err.message);
  }
}

async function restaurerDocument(id) {
  try {
    await apiJson(`/rsi/documents/${id}/restaurer`, { method: "POST" });
    chargerCorbeille();
  } catch (err) {
    alert("Erreur : " + err.message);
  }
}

// Chargement initial
chargerStats();
