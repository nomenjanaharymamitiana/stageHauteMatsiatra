from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.api.routes import auth, dagrh_documents, dashboard, documents, journal, utilisateurs
from app.db.base import Base
from app.db.session import engine

# Cree les tables si elles n'existent pas encore.
# Pour un vrai projet, prefer Alembic (migrations) a create_all en production.
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="API - Systeme de classement des dossiers (Region Haute Matsiatra)",
    description="Backend complet : authentification, cote RSI (utilisateurs, journal, "
    "restauration, tableau de bord) et cote DAG/RH (televerser, consulter, "
    "rechercher, telecharger, supprimer des documents).",
    version="0.2.0",
)

# --- Routes API ---
app.include_router(auth.router)
app.include_router(utilisateurs.router)
app.include_router(journal.router)
app.include_router(documents.router)       # /rsi/documents (corbeille + restauration)
app.include_router(dagrh_documents.router)  # /documents (cote client DAG/RH)
app.include_router(dashboard.router)


@app.get("/api", tags=["Racine"])
def racine():
    return {"message": "API - Systeme de classement des dossiers"}


# --- Frontend statique ---
# Sert le dossier ../frontend (a la racine du projet) en tant que site statique.
# Une seule commande (uvicorn app.main:app) lance donc le backend ET le frontend.
BASE_DIR = Path(__file__).resolve().parent.parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"

if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")
