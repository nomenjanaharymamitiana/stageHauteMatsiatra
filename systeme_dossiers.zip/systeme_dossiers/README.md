# Système de classement des dossiers — Région Haute Matsiatra

Application complète (backend **FastAPI** + frontend **HTML/CSS/JS**) pour la
gestion des documents administratifs, avec deux profils : **DAG/RH** (client)
et **RSI** (administrateur). Tout se lance avec **une seule commande**, sur un
seul port.

## Démarrage rapide

### 1. Prérequis
- Python 3.11+
- PostgreSQL installé et lancé (une base vide créée, ex. `dossiers_region`)

### 2. Installation

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows : venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # puis modifier DATABASE_URL et SECRET_KEY dans .env
```

```bash
createdb dossiers_region
```

### 3. Créer le premier compte RSI

```bash
python -m scripts.creer_admin
```

### 4. Lancer l'application (backend + frontend, un seul processus)

```bash
uvicorn app.main:app --reload
```

Puis ouvrir **http://localhost:8000** dans le navigateur : la page de
connexion s'affiche. Selon le rôle du compte utilisé, l'utilisateur est
redirigé vers l'espace DAG/RH ou l'espace RSI.

La documentation interactive de l'API reste disponible sur
**http://localhost:8000/docs**.

## Comment ça tient en une seule commande ?

Le frontend (`/frontend`) est un site statique pur (pas de build, pas de
Node.js). FastAPI le sert directement via `StaticFiles`, monté à la racine
`/` dans `backend/app/main.py`. Le frontend appelle l'API en JavaScript
(`fetch`) sur les mêmes routes (`/auth`, `/documents`, `/rsi/...`), donc même
origine, pas de configuration CORS à gérer.

## Structure du projet

```
systeme_dossiers/
├── backend/                  API FastAPI (voir backend/README.md pour le détail)
│   ├── app/
│   ├── scripts/creer_admin.py
│   ├── storage/               fichiers televerses (cree automatiquement)
│   └── requirements.txt
└── frontend/                 Site statique (HTML/CSS/JS vanilla)
    ├── index.html             page de connexion
    ├── dagrh.html             espace DAG/RH (documents)
    ├── rsi.html               espace RSI (administration)
    ├── css/style.css
    └── js/
        ├── api.js             helper fetch + gestion du token JWT
        ├── login.js
        ├── dagrh.js
        └── rsi.js
```

## Fonctionnalités par profil

**DAG/RH (client)** — page `/dagrh.html`
- Téléverser un document (avec numéro de référence, catégorie, format, dates)
- Consulter / rechercher (par n° de référence, catégorie, année)
- Télécharger un document
- Imprimer (ouvre le fichier et déclenche l'impression navigateur)
- Supprimer (suppression logique — récupérable par le RSI)

**RSI (administrateur)** — page `/rsi.html`
- Tableau de bord (comptes, documents par catégorie, actions journalisées)
- Gérer les comptes utilisateurs (créer, désactiver) et leurs rôles
- Consulter le journal d'activité (avec filtre par date)
- Corbeille : voir et restaurer les documents supprimés

## Tests effectués

Le backend a été testé de bout en bout (login, upload, recherche,
téléchargement, suppression/restauration, contrôle de rôle, tableau de bord)
avant livraison. Voir `backend/README.md` pour le détail des choix techniques.
